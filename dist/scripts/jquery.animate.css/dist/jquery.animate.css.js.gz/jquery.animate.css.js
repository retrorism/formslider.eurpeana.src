/*! jquery.animate.css v1.0.0 | MIT */

(function(){jQuery.fn.extend({animateCss:function(n,t,a){return this.each(function(){var e,i;return i=t/1e3,(e=$(this)).css("animation-duration",i+"s").addClass("animate "+n),setTimeout(function(){if(e.removeClass("animate "+n),a)return a(e)},t)})}})}).call(this);